﻿using GraphQL;
using GraphQL.Types;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
                 string s = GetUserData().Result;

        }

        public static async Task<string> GetUserData()
        {

            string token = "9a2b6d054ee3c1266d4371ec9dc65f9c81243662";
            var myUri = new Uri("https://api.github.com/graphql");
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var myWebRequest = WebRequest.Create(myUri);
            var myHttpWebRequest = (HttpWebRequest)myWebRequest;
            myHttpWebRequest.PreAuthenticate = true;
            myHttpWebRequest.ContentType = "application/json";
            myHttpWebRequest.Headers.Add("Authorization", "Bearer 9a2b6d054ee3c1266d4371ec9dc65f9c81243662");
            myHttpWebRequest.Method = "POST";


            RootObject obj = new RootObject();
            obj.query = "query { viewer { login } }";
            string jsondata = JsonConvert.SerializeObject(obj);

            try
            {
                using (var streamWriter = new StreamWriter(myHttpWebRequest.GetRequestStream()))
                {
                    streamWriter.Write(jsondata);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                var myWebResponse = await myWebRequest.GetResponseAsync();
                var responseStream = myWebResponse.GetResponseStream();
            }
            catch(Exception ex)
            {

            }

              return "";


   

        }
    }
}
